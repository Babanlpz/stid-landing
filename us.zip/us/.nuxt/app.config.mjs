
import { defuFn } from '/Users/ludo9p/www/stid-landing/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
