const client_manifest = {
  "../node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.0cd4f3dd.css",
    "src": "../node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.43a2d6c0.js",
    "imports": [
      "../node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.0cd4f3dd.css": {
    "file": "error-404.0cd4f3dd.css",
    "resourceType": "style"
  },
  "../node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.748cb764.css",
    "src": "../node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.e0a70e22.js",
    "imports": [
      "../node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.748cb764.css": {
    "file": "error-500.748cb764.css",
    "resourceType": "style"
  },
  "../node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.1582d788.css",
    "src": "../node_modules/nuxt/dist/app/entry.css"
  },
  "../node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.1582d788.css"
    ],
    "dynamicImports": [
      "../virtual:nuxt:/Users/ludo9p/www/stid-landing/us/.nuxt/error-component.mjs"
    ],
    "file": "entry.86468a68.js",
    "isEntry": true,
    "src": "../node_modules/nuxt/dist/app/entry.js"
  },
  "entry.1582d788.css": {
    "file": "entry.1582d788.css",
    "resourceType": "style"
  },
  "../virtual:nuxt:/Users/ludo9p/www/stid-landing/us/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.d994d226.js",
    "imports": [
      "../node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "../virtual:nuxt:/Users/ludo9p/www/stid-landing/us/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
