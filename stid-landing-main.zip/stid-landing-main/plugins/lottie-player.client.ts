import * as LottiePlayer from "@lottiefiles/lottie-player";

export default LottiePlayer;