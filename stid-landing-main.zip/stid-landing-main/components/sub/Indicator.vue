<template>
  <img src="/artefacts/indicator.svg" alt="" class="h-1 absolute left-[0.63rem] bottom-[2.19rem] desktop:left-16 desktop:bottom-16">
</template>

<script>
export default {

}
</script>

<style>

</style>