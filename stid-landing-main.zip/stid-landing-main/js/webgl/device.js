import { Viewport } from "../viewport"

export const isMobile = Viewport.width < 768
