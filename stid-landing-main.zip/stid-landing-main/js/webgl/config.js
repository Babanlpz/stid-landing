export const config = {
  background: 0x050d14,
  lines: 0x0088eb,
  green: 0x00e9a3,
  blue: 0x0088eb,
}
